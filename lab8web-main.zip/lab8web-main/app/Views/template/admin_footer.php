</section>
<footer>
    <p>&#169 2023 <a href="#">ARGUN</a> - Universitas Pelita Bangsa</p>
</footer>
</div>
</body>

</html>